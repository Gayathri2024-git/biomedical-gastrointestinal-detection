from pathlib import Path
import io
import pandas as pd
from PIL import Image

IN_DIR = Path("~/parquets_deeptune").expanduser()
OUT_DIR = Path("~/parquets_deeptune_clean").expanduser()
OUT_DIR.mkdir(parents=True, exist_ok=True)

FILES = [
    IN_DIR / "splits" / "healthy-train.parquet",
    IN_DIR / "splits" / "healthy-baseline.parquet",
    IN_DIR / "splits" / "healthy-test.parquet",
    IN_DIR / "esophagitis.parquet",
    IN_DIR / "polyps.parquet",
    IN_DIR / "ulcerative-colitis.parquet",
]

def is_valid_png_bytes(b: bytes) -> bool:
    try:
        img = Image.open(io.BytesIO(b))
        img.verify()  # fast integrity check
        return True
    except Exception:
        return False

for f in FILES:
    df = pd.read_parquet(f)

    if "images" not in df.columns:
        raise ValueError(f"{f} missing column 'images'")

    keep_mask = []
    bad = 0
    for b in df["images"].values:
        ok = isinstance(b, (bytes, bytearray)) and is_valid_png_bytes(b)
        keep_mask.append(ok)
        if not ok:
            bad += 1

    df2 = df.loc[keep_mask].reset_index(drop=True)

    out_path = OUT_DIR / f.name if f.parent.name != "splits" else (OUT_DIR / "splits" / f.name)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df2.to_parquet(out_path, index=False)

    print(f"{f.name}: kept {len(df2)}/{len(df)} (dropped {bad}) -> {out_path}")

print("DONE. Clean parquets at:", OUT_DIR)
