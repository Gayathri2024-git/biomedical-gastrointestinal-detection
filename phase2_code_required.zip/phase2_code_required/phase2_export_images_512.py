from __future__ import annotations

import io
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image

import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms


WEIGHTS = Path("/home/x2024gqa/ae_out_512/reconstructed_images_20260319_1233/autoencoder_model.pth")
OUT_ROOT = Path("/home/x2024gqa/phase2_submission_images_512")

PQ_ROOT = Path("/home/x2024gqa/parquets_deeptune_clean")
PQ = {
    "healthy-baseline": PQ_ROOT / "splits" / "healthy-baseline.parquet",
    "healthy-test": PQ_ROOT / "splits" / "healthy-test.parquet",
    "esophagitis": PQ_ROOT / "esophagitis.parquet",
    "polyps": PQ_ROOT / "polyps.parquet",
    "ulcerative-colitis": PQ_ROOT / "ulcerative-colitis.parquet",
}

IMAGE_SIZE = (512, 512)
BATCH_SIZE = 4
DEVICE = "cpu"


def load_deeptune_model(weights: Path):
    from autoencoders.autoencoder import AutoEncoder
    model = AutoEncoder(in_ch=3, use_deeper=True).to(DEVICE)
    state = torch.load(str(weights), map_location=DEVICE)
    model.load_state_dict(state)
    model.eval()
    return model


class ParquetForExport(Dataset):
    def __init__(self, parquet_path: Path):
        self.df = pd.read_parquet(parquet_path).reset_index(drop=True)
        for c in ["patient_id", "visit", "images"]:
            if c not in self.df.columns:
                raise ValueError(f"{parquet_path} missing required column {c}")

        self.tf = transforms.Compose([
            transforms.Resize(IMAGE_SIZE),
            transforms.ToTensor(),
        ])

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx: int):
        row = self.df.iloc[idx]
        pid = int(row["patient_id"])
        vis = int(row["visit"])
        img_bytes = row["images"]
        img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        img = img.resize(IMAGE_SIZE)
        x = self.tf(img)
        return x, pid, vis


def save_rgb_tensor01(t: torch.Tensor, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    arr = (t.detach().cpu().clamp(0, 1) * 255.0).byte().permute(1, 2, 0).numpy()
    Image.fromarray(arr, mode="RGB").save(path)


def save_gray_float255(arr: np.ndarray, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    arr8 = np.clip(arr, 0, 255).astype(np.uint8)
    Image.fromarray(arr8, mode="L").save(path)


def rgb_png_to_gray255(path: Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("L"), dtype=np.float32)


def main():
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    model = load_deeptune_model(WEIGHTS)

    # Step 4: originals + reconstructions
    for subdir, pq_path in PQ.items():
        out_dir = OUT_ROOT / subdir
        out_dir.mkdir(parents=True, exist_ok=True)

        ds = ParquetForExport(pq_path)
        dl = DataLoader(ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

        with torch.no_grad():
            for x, pid, vis in dl:
                x = x.to(DEVICE)
                recon, _ = model(x)

                for i in range(x.size(0)):
                    base = f"{int(pid[i])}-{int(vis[i])}"
                    save_rgb_tensor01(x[i], out_dir / f"{base}-original.png")
                    save_rgb_tensor01(recon[i], out_dir / f"{base}-reconstructed.png")

    # Step 5: reconstruction error
    for subdir in PQ.keys():
        folder = OUT_ROOT / subdir
        for orig_path in sorted(folder.glob("*-original.png")):
            base = orig_path.name.replace("-original.png", "")
            rec_path = folder / f"{base}-reconstructed.png"
            if not rec_path.exists():
                continue
            orig = rgb_png_to_gray255(orig_path)
            rec = rgb_png_to_gray255(rec_path)
            err = np.abs(rec - orig)
            save_gray_float255(err, folder / f"{base}-reconstruction_error.png")

    # Step 6: average baseline
    baseline_folder = OUT_ROOT / "healthy-baseline"
    err_paths = sorted(baseline_folder.glob("*-reconstruction_error.png"))
    stack = np.stack([np.asarray(Image.open(p).convert("L"), dtype=np.float32) for p in err_paths], axis=0)
    avg = stack.mean(axis=0)
    avg_path = baseline_folder / "average_reconstruction_error_healthy_baseline.png"
    save_gray_float255(avg, avg_path)

    # Step 7: subtraction images
    avg_img = np.asarray(Image.open(avg_path).convert("L"), dtype=np.float32)
    targets = ["healthy-test", "esophagitis", "polyps", "ulcerative-colitis"]
    for subdir in targets:
        folder = OUT_ROOT / subdir
        for err_path in sorted(folder.glob("*-reconstruction_error.png")):
            base = err_path.name.replace("-reconstruction_error.png", "")
            err = np.asarray(Image.open(err_path).convert("L"), dtype=np.float32)
            sub = np.abs(err - avg_img)
            save_gray_float255(sub, folder / f"{base}-subtraction_reconstruction_error.png")

    # Step 8: global scaling
    global_max = 0.0
    for subdir in targets:
        folder = OUT_ROOT / subdir
        for p in folder.glob("*-subtraction_reconstruction_error.png"):
            arr = np.asarray(Image.open(p).convert("L"), dtype=np.float32)
            global_max = max(global_max, float(arr.max()))

    if global_max <= 0:
        global_max = 255.0

    print("Global scaling max used:", global_max)

    for subdir in targets:
        folder = OUT_ROOT / subdir
        for p in folder.glob("*-subtraction_reconstruction_error.png"):
            base = p.name.replace("-subtraction_reconstruction_error.png", "")
            arr = np.asarray(Image.open(p).convert("L"), dtype=np.float32)
            scaled = (arr / global_max) * 255.0
            save_gray_float255(scaled, folder / f"{base}-scaled_subtraction_reconstruction_error.png")

    print("DONE. Images saved at:", OUT_ROOT)


if __name__ == "__main__":
    main()
