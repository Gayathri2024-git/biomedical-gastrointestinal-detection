from pathlib import Path
import pandas as pd

IN_PARQUET = Path("./parquets/healthy_all.parquet")
OUT_DIR = Path("./parquets/splits")
OUT_DIR.mkdir(parents=True, exist_ok=True)

df = pd.read_parquet(IN_PARQUET).sample(frac=1.0, random_state=42).reset_index(drop=True)

n = len(df)
n_train = int(n * 0.70)
n_base = int(n * 0.10)
# rest is test

df_train = df.iloc[:n_train].reset_index(drop=True)
df_base  = df.iloc[n_train:n_train+n_base].reset_index(drop=True)
df_test  = df.iloc[n_train+n_base:].reset_index(drop=True)

df_train.to_parquet(OUT_DIR / "healthy-train.parquet", index=False)
df_base.to_parquet(OUT_DIR / "healthy-baseline.parquet", index=False)  # renamed validation
df_test.to_parquet(OUT_DIR / "healthy-test.parquet", index=False)

print("Counts:")
print("train:", len(df_train))
print("baseline:", len(df_base))
print("test:", len(df_test))
print("Saved to:", OUT_DIR)
