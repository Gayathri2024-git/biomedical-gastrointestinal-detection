from pathlib import Path
import pandas as pd

IN_DIR = Path("~/parquets").expanduser()
OUT_DIR = Path("~/parquets_deeptune").expanduser()
OUT_DIR.mkdir(parents=True, exist_ok=True)

files = [
    IN_DIR / "healthy_all.parquet",
    IN_DIR / "esophagitis.parquet",
    IN_DIR / "polyps.parquet",
    IN_DIR / "ulcerative-colitis.parquet",
    IN_DIR / "splits" / "healthy-train.parquet",
    IN_DIR / "splits" / "healthy-baseline.parquet",
    IN_DIR / "splits" / "healthy-test.parquet",
]

for f in files:
    df = pd.read_parquet(f)

    if "images" not in df.columns and "image" in df.columns:
        df = df.rename(columns={"image": "images"})

    # DeepTune also usually expects a label column; keep yours as-is
    # Ensure bytes column is object dtype (it will be)
    out_path = OUT_DIR / f.name if f.parent.name != "splits" else (OUT_DIR / "splits" / f.name)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(out_path, index=False)
    print("Wrote:", out_path, "cols:", list(df.columns))

print("DONE. New parquets at:", OUT_DIR)
