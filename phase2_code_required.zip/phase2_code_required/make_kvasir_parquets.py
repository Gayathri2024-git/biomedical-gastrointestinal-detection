from __future__ import annotations

import io
from pathlib import Path

import pandas as pd
from PIL import Image


def img_to_png_bytes(img_path: Path, resize_to: tuple[int, int] | None = None) -> bytes:
    """Load image, optionally resize, and return PNG bytes."""
    img = Image.open(img_path).convert("RGB")
    if resize_to is not None:
        img = img.resize(resize_to)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def collect_images(folder: Path) -> list[Path]:
    exts = {".jpg", ".jpeg", ".png"}
    return [p for p in folder.rglob("*") if p.suffix.lower() in exts]


def build_parquet(
    image_paths: list[Path],
    out_path: Path,
    label_value: int,
    resize_to: tuple[int, int] | None = None,
) -> None:
    rows = []
    for i, p in enumerate(sorted(image_paths), start=1):
        rows.append(
            {
                "patient_id": int(i),   # simple unique ID
                "visit": 1,
                "image_path": str(p),
                "image": img_to_png_bytes(p, resize_to=resize_to),
                "label": int(label_value),  # DeepTune expects a label column
            }
        )

    df = pd.DataFrame(rows)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(out_path, index=False)
    print(f"Wrote {len(df)} rows -> {out_path}")


def main():
    KVASIR_ROOT = Path("/home/x2024gqa/datasets/kvasir-dataset-v3")  
    OUT_DIR = Path("./parquets")
    RESIZE_TO = (224, 224)

    # Healthy: combine these folders
    healthy_folders = [
        KVASIR_ROOT / "normal-z-line",
        KVASIR_ROOT / "normal-pylorus",
        # optionally: KVASIR_ROOT / "normal-cecum",
    ]

    healthy_imgs: list[Path] = []
    for f in healthy_folders:
        healthy_imgs += collect_images(f)

    build_parquet(
        healthy_imgs,
        OUT_DIR / "healthy_all.parquet",
        label_value=0,
        resize_to=RESIZE_TO,
    )

    # Pathologies (one parquet per condition)
    pathologies = {
        "esophagitis": KVASIR_ROOT / "esophagitis",
        "polyps": KVASIR_ROOT / "polyps",
        "ulcerative-colitis": KVASIR_ROOT / "ulcerative-colitis",
    }

    for name, folder in pathologies.items():
        imgs = collect_images(folder)
        build_parquet(
            imgs,
            OUT_DIR / f"{name}.parquet",
            label_value=0,
            resize_to=RESIZE_TO,
        )


if __name__ == "__main__":
    main()
